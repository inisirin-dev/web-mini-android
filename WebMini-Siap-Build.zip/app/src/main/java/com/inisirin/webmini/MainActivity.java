package com.inisirin.webmini;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText urlInput;
    private WebView webView;
    private ProgressBar progressBar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("WEB MINI");
        title.setTextSize(18);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14), 0, dp(14), 0);
        title.setBackgroundColor(Color.rgb(35, 95, 170));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout urlRow = new LinearLayout(this);
        urlRow.setOrientation(LinearLayout.HORIZONTAL);
        urlRow.setPadding(dp(6), dp(6), dp(6), dp(2));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextSize(14);
        urlInput.setHint("Tempel alamat website...");
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlRow.addView(urlInput, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button pasteButton = new Button(this);
        pasteButton.setText("TEMPEL");
        urlRow.addView(pasteButton, new LinearLayout.LayoutParams(-2, dp(48)));

        root.addView(urlRow, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout buttonRow = new LinearLayout(this);
        buttonRow.setOrientation(LinearLayout.HORIZONTAL);
        buttonRow.setPadding(dp(6), 0, dp(6), dp(4));

        Button openButton = new Button(this);
        openButton.setText("BUKA");
        buttonRow.addView(openButton, new LinearLayout.LayoutParams(0, dp(44), 1));

        Button homeButton = new Button(this);
        homeButton.setText("BERANDA");
        buttonRow.addView(homeButton, new LinearLayout.LayoutParams(0, dp(44), 1));

        root.addView(buttonRow, new LinearLayout.LayoutParams(-1, -2));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        root.addView(progressBar, new LinearLayout.LayoutParams(-1, dp(3)));

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));

        Button backButton = new Button(this);
        backButton.setText("◀ KEMBALI");
        root.addView(backButton, new LinearLayout.LayoutParams(-1, dp(46)));

        setContentView(root);

        pasteButton.setOnClickListener(v -> pasteUrl());
        openButton.setOnClickListener(v -> openUrl());
        urlInput.setOnEditorActionListener((v, actionId, event) -> {
            openUrl();
            return true;
        });
        homeButton.setOnClickListener(v -> {
            webView.loadUrl("about:blank");
            urlInput.setText("");
        });
        backButton.setOnClickListener(v -> goBack());
    }

    private void pasteUrl() {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null && clipboard.hasPrimaryClip()) {
            ClipData clip = clipboard.getPrimaryClip();
            if (clip != null && clip.getItemCount() > 0) {
                CharSequence text = clip.getItemAt(0).coerceToText(this);
                if (text != null) urlInput.setText(text.toString().trim());
            }
        } else {
            Toast.makeText(this, "Clipboard kosong", Toast.LENGTH_SHORT).show();
        }
    }

    private void openUrl() {
        String url = urlInput.getText().toString().trim();
        if (url.isEmpty()) {
            Toast.makeText(this, "Tempel alamat website terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.matches("(?i)^https?://.*")) url = "https://" + url;
        if (!android.util.Patterns.WEB_URL.matcher(url).matches()) {
            Toast.makeText(this, "Alamat website tidak valid", Toast.LENGTH_SHORT).show();
            return;
        }
        urlInput.setText(url);
        ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(urlInput.getWindowToken(), 0);
        webView.loadUrl(url);
    }

    private void goBack() {
        if (webView.canGoBack()) webView.goBack();
        else Toast.makeText(this, "Tidak ada halaman sebelumnya", Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }
}
