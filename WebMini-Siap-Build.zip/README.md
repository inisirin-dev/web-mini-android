# Web Mini Android

Aplikasi Android WebView sederhana dengan kolom URL yang selalu terlihat.

## Build APK

Persyaratan:
- JDK 17
- Android SDK Platform 34
- Android Build Tools 34.x
- Gradle 8.2 atau kompatibel dengan Android Gradle Plugin 8.2.2

Dari folder proyek, jalankan:
```bash
gradle assembleDebug
```

APK debug akan dibuat di:
`app/build/outputs/apk/debug/app-debug.apk`

## Build lewat GitHub Actions

Unggah semua isi folder ini ke repositori GitHub. Tambahkan file workflow di
`.github/workflows/build.yml` (contoh tersedia di bawah), lalu jalankan workflow.

Target minimum Android: 8.1 (API 27).
